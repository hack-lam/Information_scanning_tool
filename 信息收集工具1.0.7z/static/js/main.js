// 全局JavaScript文件
$(document).ready(function() {
    // 初始化
    initTheme();
    initBackToTop();
    initTooltips();
    
    // 主题切换
    $('#themeToggle').on('click', function() {
        toggleTheme();
    });
});

// 主题管理
function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);
}

function toggleTheme() {
    const currentTheme = $('body').hasClass('dark-theme') ? 'dark' : 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
}

function setTheme(theme) {
    const $body = $('body');
    const $icon = $('#themeIcon');
    
    if (theme === 'dark') {
        $body.addClass('dark-theme');
        $icon.removeClass('fa-moon').addClass('fa-sun');
    } else {
        $body.removeClass('dark-theme');
        $icon.removeClass('fa-sun').addClass('fa-moon');
    }
    
    localStorage.setItem('theme', theme);
}

// 返回顶部功能
function initBackToTop() {
    const $backToTop = $('#backToTop');
    
    $(window).scroll(function() {
        if ($(this).scrollTop() > 200) {
            $backToTop.fadeIn();
        } else {
            $backToTop.fadeOut();
        }
    });
    
    $backToTop.on('click', function() {
        $('html, body').animate({scrollTop: 0}, 800);
        return false;
    });
}

// 初始化工具提示
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// 通用AJAX错误处理
$(document).ajaxError(function(event, xhr, settings, thrownError) {
    console.error('AJAX Error:', thrownError);
    
    let errorMessage = '请求失败，请稍后重试';
    
    if (xhr.status === 0) {
        errorMessage = '网络连接失败，请检查网络连接';
    } else if (xhr.status === 404) {
        errorMessage = '请求的资源不存在';
    } else if (xhr.status === 500) {
        errorMessage = '服务器内部错误';
    } else if (xhr.responseJSON && xhr.responseJSON.message) {
        errorMessage = xhr.responseJSON.message;
    }
    
    showNotification(errorMessage, 'error');
});

// 通知系统
function showNotification(message, type = 'info') {
    const types = {
        'success': 'alert-success',
        'error': 'alert-danger',
        'warning': 'alert-warning',
        'info': 'alert-info'
    };
    
    const icons = {
        'success': 'fas fa-check-circle',
        'error': 'fas fa-exclamation-circle',
        'warning': 'fas fa-exclamation-triangle',
        'info': 'fas fa-info-circle'
    };
    
    const alertClass = types[type] || types['info'];
    const iconClass = icons[type] || icons['info'];
    
    const notificationHtml = `
        <div class="alert ${alertClass} alert-dismissible fade show notification" 
             style="position: fixed; top: 20px; right: 20px; z-index: 1050; min-width: 300px;">
            <i class="${iconClass} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    $('body').append(notificationHtml);
    
    // 5秒后自动隐藏
    setTimeout(() => {
        $('.notification').fadeOut(function() {
            $(this).remove();
        });
    }, 5000);
}

// 表单验证工具
function validateForm(formSelector) {
    const $form = $(formSelector);
    let isValid = true;
    
    $form.find('input[required], select[required], textarea[required]').each(function() {
        const $field = $(this);
        const value = $field.val().trim();
        
        // 移除之前的错误状态
        $field.removeClass('is-invalid');
        $field.siblings('.invalid-feedback').remove();
        
        if (!value) {
            $field.addClass('is-invalid');
            $field.after('<div class="invalid-feedback">此字段不能为空</div>');
            isValid = false;
        } else if ($field.attr('type') === 'email' && !isValidEmail(value)) {
            $field.addClass('is-invalid');
            $field.after('<div class="invalid-feedback">请输入有效的邮箱地址</div>');
            isValid = false;
        } else if ($field.hasClass('domain-input') && !isValidDomain(value)) {
            $field.addClass('is-invalid');
            $field.after('<div class="invalid-feedback">请输入有效的域名</div>');
            isValid = false;
        }
    });
    
    return isValid;
}

// 邮箱验证
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// 域名验证
function isValidDomain(domain) {
    const domainRegex = /^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
    return domainRegex.test(domain);
}

// 格式化字节大小
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// 格式化时间
function formatTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) {
        return `${days}天前`;
    } else if (hours > 0) {
        return `${hours}小时前`;
    } else if (minutes > 0) {
        return `${minutes}分钟前`;
    } else {
        return '刚刚';
    }
}

// 复制到剪贴板
function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(() => {
            showNotification('已复制到剪贴板', 'success');
        }).catch(err => {
            console.error('复制失败:', err);
            showNotification('复制失败', 'error');
        });
    } else {
        // 兼容旧浏览器
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            showNotification('已复制到剪贴板', 'success');
        } catch (err) {
            console.error('复制失败:', err);
            showNotification('复制失败', 'error');
        } finally {
            textArea.remove();
        }
    }
}

// 导出数据为JSON
function exportAsJSON(data, filename) {
    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || 'export.json';
    document.body.appendChild(a);
    a.click();
    
    URL.revokeObjectURL(url);
    document.body.removeChild(a);
    
    showNotification('文件已导出', 'success');
}

// 导出数据为CSV
function exportAsCSV(data, filename, headers) {
    let csvContent = '';
    
    // 添加表头
    if (headers) {
        csvContent += headers.join(',') + '\n';
    }
    
    // 添加数据行
    data.forEach(row => {
        if (Array.isArray(row)) {
            csvContent += row.map(field => `"${field}"`).join(',') + '\n';
        } else if (typeof row === 'object') {
            const values = headers ? headers.map(header => row[header] || '') : Object.values(row);
            csvContent += values.map(field => `"${field}"`).join(',') + '\n';
        }
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || 'export.csv';
    document.body.appendChild(a);
    a.click();
    
    URL.revokeObjectURL(url);
    document.body.removeChild(a);
    
    showNotification('CSV文件已导出', 'success');
}

// 加载动画控制
let loadingCount = 0;

function showLoading(message = '正在处理中...') {
    loadingCount++;
    
    if ($('#loadingOverlay').length === 0) {
        const loadingHtml = `
            <div id="loadingOverlay" class="loading-overlay">
                <div class="loading-content">
                    <div class="spinner-border text-primary mb-3" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div class="loading-text">${message}</div>
                </div>
            </div>
        `;
        $('body').append(loadingHtml);
    }
    
    $('#loadingOverlay').show();
    $('.loading-text').text(message);
}

function hideLoading() {
    loadingCount = Math.max(0, loadingCount - 1);
    
    if (loadingCount === 0) {
        $('#loadingOverlay').hide();
    }
}

// 数据表格增强
function enhanceTable(tableSelector) {
    const $table = $(tableSelector);
    
    // 添加排序功能
    $table.find('thead th').each(function(index) {
        const $th = $(this);
        if (!$th.hasClass('no-sort')) {
            $th.addClass('sortable').css('cursor', 'pointer');
            $th.append(' <i class="fas fa-sort text-muted"></i>');
            
            $th.on('click', function() {
                sortTable($table, index);
            });
        }
    });
    
    // 添加搜索功能
    if ($table.siblings('.table-search').length === 0) {
        const searchHtml = `
            <div class="table-search mb-3">
                <div class="input-group">
                    <span class="input-group-text">
                        <i class="fas fa-search"></i>
                    </span>
                    <input type="text" class="form-control" placeholder="搜索表格内容...">
                </div>
            </div>
        `;
        $table.before(searchHtml);
        
        $table.siblings('.table-search').find('input').on('input', function() {
            filterTable($table, $(this).val());
        });
    }
}

// 表格排序
function sortTable($table, columnIndex) {
    const $tbody = $table.find('tbody');
    const $rows = $tbody.find('tr').toArray();
    const $th = $table.find('thead th').eq(columnIndex);
    
    const isAscending = !$th.hasClass('sort-asc');
    
    // 清除其他列的排序标识
    $table.find('thead th').removeClass('sort-asc sort-desc');
    $table.find('thead th i').removeClass('fa-sort-up fa-sort-down').addClass('fa-sort');
    
    // 设置当前列的排序标识
    $th.addClass(isAscending ? 'sort-asc' : 'sort-desc');
    $th.find('i').removeClass('fa-sort').addClass(isAscending ? 'fa-sort-up' : 'fa-sort-down');
    
    // 排序行
    $rows.sort(function(a, b) {
        const aValue = $(a).find('td').eq(columnIndex).text().trim();
        const bValue = $(b).find('td').eq(columnIndex).text().trim();
        
        // 尝试数字比较
        const aNum = parseFloat(aValue);
        const bNum = parseFloat(bValue);
        
        if (!isNaN(aNum) && !isNaN(bNum)) {
            return isAscending ? aNum - bNum : bNum - aNum;
        }
        
        // 字符串比较
        return isAscending ? 
            aValue.localeCompare(bValue) : 
            bValue.localeCompare(aValue);
    });
    
    // 重新插入排序后的行
    $tbody.html($rows);
}

// 表格过滤
function filterTable($table, searchTerm) {
    const $tbody = $table.find('tbody');
    const $rows = $tbody.find('tr');
    
    if (!searchTerm) {
        $rows.show();
        return;
    }
    
    $rows.each(function() {
        const $row = $(this);
        const text = $row.text().toLowerCase();
        
        if (text.includes(searchTerm.toLowerCase())) {
            $row.show();
        } else {
            $row.hide();
        }
    });
}

// 图表颜色主题
const chartColors = {
    primary: '#007bff',
    secondary: '#6c757d',
    success: '#28a745',
    danger: '#dc3545',
    warning: '#ffc107',
    info: '#17a2b8',
    light: '#f8f9fa',
    dark: '#343a40'
};

// 获取图表颜色数组
function getChartColors(count = 6) {
    const colors = Object.values(chartColors);
    const result = [];
    
    for (let i = 0; i < count; i++) {
        result.push(colors[i % colors.length]);
    }
    
    return result;
}

// 防抖函数
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func(...args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func(...args);
    };
}

// 节流函数
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// 本地存储封装
const storage = {
    set: function(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (e) {
            console.error('存储失败:', e);
            return false;
        }
    },
    
    get: function(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (e) {
            console.error('读取存储失败:', e);
            return defaultValue;
        }
    },
    
    remove: function(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (e) {
            console.error('删除存储失败:', e);
            return false;
        }
    },
    
    clear: function() {
        try {
            localStorage.clear();
            return true;
        } catch (e) {
            console.error('清空存储失败:', e);
            return false;
        }
    }
};

// 页面离开确认
function confirmPageLeave(message = '确定要离开当前页面吗？未保存的更改将丢失。') {
    window.addEventListener('beforeunload', function(e) {
        e.preventDefault();
        e.returnValue = message;
        return message;
    });
}

// 移除页面离开确认
function removePageLeaveConfirm() {
    window.removeEventListener('beforeunload', function() {});
}

// 键盘快捷键
function addKeyboardShortcut(keys, callback, description) {
    document.addEventListener('keydown', function(e) {
        const keyCombo = [];
        
        if (e.ctrlKey) keyCombo.push('ctrl');
        if (e.altKey) keyCombo.push('alt');
        if (e.shiftKey) keyCombo.push('shift');
        if (e.metaKey) keyCombo.push('meta');
        
        keyCombo.push(e.key.toLowerCase());
        
        if (keyCombo.join('+') === keys.toLowerCase()) {
            e.preventDefault();
            callback(e);
        }
    });
    
    // 可以在这里添加快捷键帮助信息
    if (description) {
        console.log(`已注册快捷键: ${keys} - ${description}`);
    }
}

// 全屏切换
function toggleFullscreen(element = document.documentElement) {
    if (!document.fullscreenElement) {
        element.requestFullscreen().catch(err => {
            showNotification('无法进入全屏模式', 'error');
        });
    } else {
        document.exitFullscreen();
    }
}

// 打印页面
function printPage(title) {
    if (title) {
        const originalTitle = document.title;
        document.title = title;
        window.print();
        document.title = originalTitle;
    } else {
        window.print();
    }
}

// 分享功能
function shareContent(data) {
    if (navigator.share) {
        navigator.share(data).catch(err => {
            console.error('分享失败:', err);
        });
    } else {
        // 备用方案：复制链接
        const url = data.url || window.location.href;
        copyToClipboard(url);
        showNotification('链接已复制到剪贴板', 'info');
    }
}
